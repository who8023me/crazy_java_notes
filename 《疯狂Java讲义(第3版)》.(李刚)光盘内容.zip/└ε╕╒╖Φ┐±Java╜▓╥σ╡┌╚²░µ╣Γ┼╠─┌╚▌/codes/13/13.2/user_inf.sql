create table user_inf
(
	user_id int primary key auto_increment,
	user_name varchar(255)
);