package org.crazyit.tetris.exception;

public class GameException extends RuntimeException {

	public GameException(String s) {
		super(s);
	}
}
