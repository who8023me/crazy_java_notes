package org.crazyit.gamehall.chatroom.client;

import org.crazyit.gamehall.chatroom.client.ui.MainFrame;
import org.crazyit.gamehall.commons.User;

/**
 * ��ſͻ��˵�һЩ��Ϣ
 * @author yangenxiong
 *
 */
public class ClientContext {

	public static User user;
	
	public static MainFrame mainFrame;
}
