package org.crazyit.ioc.context.object.interfaces;

public interface Interface1 {

}
