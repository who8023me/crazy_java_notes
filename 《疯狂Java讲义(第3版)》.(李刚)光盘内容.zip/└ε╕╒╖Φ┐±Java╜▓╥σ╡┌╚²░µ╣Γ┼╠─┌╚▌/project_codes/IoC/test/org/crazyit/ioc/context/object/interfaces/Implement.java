package org.crazyit.ioc.context.object.interfaces;

public class Implement implements Interface2 {

}
