package org.crazyit.transaction.service;

import java.util.List;

import org.crazyit.transaction.model.Role;

public interface RoleService {

	/**
	 * ����ȫ���Ľ�ɫ
	 * @return
	 */
	List<Role> getRoles();
}
