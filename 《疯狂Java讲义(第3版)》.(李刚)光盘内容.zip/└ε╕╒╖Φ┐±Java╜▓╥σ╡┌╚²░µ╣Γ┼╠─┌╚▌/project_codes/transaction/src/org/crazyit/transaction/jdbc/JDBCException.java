package org.crazyit.transaction.jdbc;

/**
 * jdbc�쳣��
 * @author yangenxiong
 *
 */
public class JDBCException extends RuntimeException {

	public JDBCException(String message) {
		super(message);
	}
}
