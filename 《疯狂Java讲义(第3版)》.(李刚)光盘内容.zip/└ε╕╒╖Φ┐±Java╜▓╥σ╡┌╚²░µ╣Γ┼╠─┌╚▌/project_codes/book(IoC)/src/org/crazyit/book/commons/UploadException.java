package org.crazyit.book.commons;

public class UploadException extends RuntimeException {

	public UploadException(String m) {
		super(m);
	}
}
